# Docker Golang Application


#### Run
```bash
docker build -t goapp . && docker run -p 8080:8080 goapp
```